<div align="center"><h1>Muck Mob Spawner</h1><h4>This plugin is a simple server sided mob spawner for the game Muck, by DaniDev. This plugin only works if you are the host of the lobby.</h4></div>

<div align="center">
<a href="https://github.com/CrafterBotOfficial/MuckMobSpawner/blob/main/LICENSE">
<img src="https://img.shields.io/badge/license-MIT-green">
</a>
</div>

## Installation
To install this plugin download [BepInEx](https://github.com/BepInEx/BepInEx/releases/tag/v5.4.21) and put the contents of the BepInEx ZIP file into your Muck folder. Then run the Muck.exe. This will configure your BepInEx install. After you have completed the following steps go to the ``Muck>BepInEx>plugins`` folder and copy and paste the contents of this [plugins ZIP](https://github.com/CrafterBotOfficial/MuckMobSpawner/releases/).

## Usage
To use this plugin go create a lobby. When you create a host you will become the [(Host+)](https://en.wikipedia.org/wiki/Game_server#), then start the game. Next click on the menu view key ``(Default:F1)``. Finally press on the mob you want to spawn. To navigate the menu either press the arrow keys ``(can be configured)``, or the arrow buttons on the sceen.

## Legal
* The menu utilized is a ripped asset from the game Muck, by DaniDev. The asset has been highly modified for this purpose.
